"""Utilitaires pour RAA-NORM."""
